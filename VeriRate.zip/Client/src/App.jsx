import AllRoutes from "./routes/AllRoutes";

const App = () => {
  return (
    
    // <div className="flex flex-col min-h-screen">
    //   <Header />
    //   <div className="md:grid grid-cols-12 flex-grow h-0 flex-1 flex">
    //     <div className="md:col-span-2">
    //       <Sidebar />
    //     </div>
    //     <div className="md:col-span-10 bg-red-500 flex-grow h-auto">
    //       Dummy DIV
    //     </div>
    //   </div>
    // </div>
    <div>
        <AllRoutes />
    </div>

    
  );
};

export default App;
